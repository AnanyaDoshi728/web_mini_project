const { response } = require('express');
const express = require('express');
const { request } = require('http');
const app = express();
const router = express.Router();
const XMLHttpRequest = require('xhr2');
const XMLParser = require('xml2js').parseString;
const axios = require('axios');
const mongoose = require('mongoose');
const Blog = require('./models/blog');



// router.get('/home', async function(request,response){
//      await response.render('index');
// });

// router.get('/stopwatch',(request,response) => {
//     response.render('stopwatch');
// });

// router.get('/recipe_planner',(request,response) => {
//     response.render('recipe_planner');
// });

// router.post('/recipe_planner',async function (request,response){
     
//     const appKey = "47328a56466c3ab3aaeedaf7c11f7e3f";
//     const appId = "a445419e";

//     let apiUrl = `https://api.edamam.com/search?app_id=${appId}&app_key=${appKey}&q=${request.body.queryParameter}&diet=${request.body.selectedDiet}&ingr=${request.body.numberOfIngredients}&health=${request.body.selectedLabel}`;
    
//     const makeRequest = (dataSource) => {
    
//         return new Promise((resolve,reject) => {
//             const request = new XMLHttpRequest();
    
//             request.addEventListener('readystatechange',() => {
//             if(request.readyState === 4 && request.status === 200){
//                 const data = JSON.parse(request.responseText);
//                 // console.log(data);
//                 resolve(data);
//             }
//             else if(request.readyState === 4){
//                 reject("Error getting data");
//             }
//             });
        
//             request.open('GET',dataSource);
//             request.send();
//         });
//     };

//     makeRequest(apiUrl).then((data) => {

             
//         let hitsArray = data['hits'];
//         let resultsArray = [];
        
    
//         for(let i=0;i<hitsArray.length;i++){

//             let recipe = hitsArray[i]['recipe'];

//             let calories = Math.round(recipe['calories']);
//             let imageUrl = recipe['image'];
//             let label  = recipe['label'];
//             let ingredientLines = recipe['ingredientLines'];
//             let recipeUrl = recipe['url'];

//            resultsArray.push({calories,label,ingredientLines,recipeUrl,imageUrl});
         
//         }
//         response.render('recipe_planner_output',{data: resultsArray});
        
//         console.log(resultsArray);
//     }).catch((error) => {
//         console.log('error: ',error.message);
//     });
    

// });

// router.get('/navbar',(request,response) => {
//     response.render('navbar');
// });

// router.get('/disease',(request,response) => {
  
//     axios.get(`https://wsearch.nlm.nih.gov/ws/query?db=healthTopics&term=title:Diabetes`)
//      .then(result => {
        
//        XMLParser(result.data, (notParsed,parsedData) => {
              
//              if(parsedData.nlmSearchResult.list[0].document[0].content){
                 
//                 parsedData.nlmSearchResult.list[0].document[0].content.forEach(element => {

//                     if(element['$'].name === 'FullSummary'){
//                         console.log(element);
//                         response.render('disease',{data: element});
//                     }
//                 });
               
//              }
//              else{
//                 response.render('404');
//              }
//        });

        
//      }).catch(error => {
//          console.log(error);
//      });
 
// });



//blog routes 


// module.exports = router;