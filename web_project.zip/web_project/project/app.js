const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Blog = require('./models/blog');
const mySqlInstance = require('mysql');
const XMLHttpRequest = require('xhr2');
const XMLParser = require('xml2js').parseString;
const axios = require('axios');
// const session = require('express-session');


const app = express();
const PORT = 3000;
const router = require('./router');
const { application, response } = require('express');
const { request } = require('http');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static('public'));
app.set('view engine','ejs');

const mySqlConnection = mySqlInstance.createConnection({
  user: 'root',
  password: '',
  host: 'localhost',
  port: 3306,
  database: 'database1'
});

mySqlConnection.connect((error) => {
  if(error){
      throw new Error(`Could not connect to database\n\n${error}`);
  }
  else{
      console.log('Successfully connected to database');
  }
});



let tableCreation =   `create table if not exists Users1(
  username varchar(20) not null,
  user_email varchar(50) not null,
  password varchar(20) not null,
  primary key(user_email)

)`;

mySqlConnection.query(tableCreation,function(error){

  if(error){
      console.log(`Could not connect to database\n\n${error}`);
      // response.render('404');
  }
  else{
      console.log('Table Users created or table already exists');

  }

});

  // sign-up
  app.get('/',(request,response) => {
    response.render('sign_up');
  });

app.post('/',(request,response) => {

  console.log(request.body);

  let insertion =  `insert into Users1 values?`;

  let userInputArray = [
            [   request.body.signUpName,
                request.body.signUpEmail,
                request.body.signUpPassword
            ],
        ];

  mySqlConnection.query(insertion,[userInputArray],function(error,results){
                  if(error){
                      
                     console.log('Error in inserting data');
                     response.render('error');
                     console.log(error);
                    
                      
                  }else{
                      console.log('Values succesfully inserted into database');
                      response.render('login');
                    
          }
});

});

  //login
  app.get('/login',(request,response) => {
    response.render('login');
  });

  app.post('/login',(request,response) => {

    let email = request.body.loginEmail;
    let password = request.body.loginPassword;

    let verification = `select * from Users1 where user_email=? and password=?`;

    mySqlConnection.query(verification,[email,password],function(error,results){
       if(error){
         console.log('Error in logging user in');
        
         console.log(error);
       }
       else{
         if(results.length > 0){
          console.log(results);

          let name = [];
          
          results.forEach(record => {
            name.push(record.username);
          })

           response.render('index',{data: name});
         }else{
          response.render('error');
           console.log('User does not exist');
         }
       }

    });

  });

  app.get('/home', async function(request,response){
    await response.render('index');
});

app.get('/stopwatch',(request,response) => {
    response.render('stopwatch');
});

app.get('/bmi',(request,response) => {
  response.render('bmi');
})

  app.get('/recipe_planner',(request,response) => {
    response.render('recipe_planner');
});

app.post('/recipe_planner',async function (request,response){
     
  const appKey = "47328a56466c3ab3aaeedaf7c11f7e3f";
  const appId = "a445419e";

  let apiUrl = `https://api.edamam.com/search?app_id=${appId}&app_key=${appKey}&q=${request.body.queryParameter} 
                &diet=${request.body.selectedDiet}&ingr=${request.body.numberOfIngredients}&health=${request.body.selectedLabel}`;
  
  const makeRequest = (dataSource) => {
  
      return new Promise((resolve,reject) => {
          const request = new XMLHttpRequest();
  
          request.addEventListener('readystatechange',() => {
          if(request.readyState === 4 && request.status === 200){
              const data = JSON.parse(request.responseText);
              // console.log(data);
              resolve(data);
          }
          else if(request.readyState === 4){
              reject("Error getting data");
          }
          });
      
          request.open('GET',dataSource);
          request.send();
      });
  };

  makeRequest(apiUrl).then((data) => {

           
      let hitsArray = data['hits'];
      let resultsArray = [];
      
  
      for(let i=0;i<hitsArray.length;i++){

          let recipe = hitsArray[i]['recipe'];

          let calories = Math.round(recipe['calories']);
          let imageUrl = recipe['image'];
          let label  = recipe['label'];
          let ingredientLines = recipe['ingredientLines'];
          let recipeUrl = recipe['url'];

         resultsArray.push({calories,label,ingredientLines,recipeUrl,imageUrl});
       
      }
      response.render('recipe_planner_output',{data: resultsArray});
      
      console.log(resultsArray);
  }).catch((error) => {
      console.log('error: ',error.message);
      response.render('error');
  });
  

});

app.get('/disease',(request,response) => {
  
    axios.get(`https://wsearch.nlm.nih.gov/ws/query?db=healthTopics&term=title:Diabetes`)
     .then(result => {
        
       XMLParser(result.data, (notParsed,parsedData) => {
              
             if(parsedData.nlmSearchResult.list[0].document[0].content){
                 
                parsedData.nlmSearchResult.list[0].document[0].content.forEach(element => {

                    if(element['$'].name === 'FullSummary'){
                        console.log(element);
                        response.render('disease',{data: element});
                    }
                });
               
             }
             else{
                response.render('404');
             }
       });

        
     }).catch(error => {
         console.log(error);
     });
 
});


app.get('/questions',(request,response) => {
  const getQuestions = (quizUrl) => {

    const quizRequest = new XMLHttpRequest();
    
    return new Promise((resolve,reject) => {
        quizRequest.addEventListener('readystatechange',() => {
       
            if(quizRequest.readyState === 4 && quizRequest.status === 200){
                  const parsedQuizRequest = JSON.parse(quizRequest.responseText);
                  const quizResults = parsedQuizRequest['results'];

                  var questionsAndAnswers = [];
                 
                  //the response contains  1 correct answer and an array of 3 incorrect answers
                  //so create a common array conatining all 4 answers
                  //randomize the array using Fisher Yates shuffle and push it as answers in questionsAndAnswers array

                  for(let i=0;i<quizResults.length;i++){
                      var currentResult = quizResults[i];
                      var currentQuestion = currentResult['question'];

                      //push correct answer and incorrect answers into one array
                      var currentCorrectAnwser = currentResult['correct_answer'];
                      var currentAnswers = currentResult['incorrect_answers'];
                      currentAnswers.push(currentCorrectAnwser);
                      
                      //randomize the answers array
                      //so that the correct answer is at random positions each time
                      for(let i=currentAnswers.length-1;i>0;i--){
                          var temporary = Math.floor(Math.random() * (i+1));
                          [currentAnswers[i],currentAnswers[temporary]] = [currentAnswers[temporary],currentAnswers[i]];
                      }
                       questionsAndAnswers.push({question: currentQuestion,
                                                answers: currentAnswers,
                                                correctAnswer: currentCorrectAnwser});
                  }
                  console.log(quizResults.length,questionsAndAnswers.length);
                //   console.log(questionsAndAnswers);
                  resolve(questionsAndAnswers);
            }
            else if(quizRequest.readyState === 4){ 
                 reject("Error fetching data");
            }
        });

       quizRequest.open("GET",quizUrl);
       quizRequest.send();
    });
};

const quizUrl = "https://opentdb.com/api.php?amount=10&category=21&type=multiple";


getQuestions(quizUrl).then(questionsAndAnswers => {
    response.render('questions',{data: questionsAndAnswers});

}).catch(error => {
 
    console.log(error);
    response.render('error');
});
});

//   response.render('testing');
// })


app.get('/about', (req, res) => {
    res.render('about', { title: 'About' });
  });

app.get('/blogs',(req,res)=>{
    Blog.find().sort({createdAt: -1})
      .then((result)=>{
        res.render('index_blogs',{title:'All Blogs',blogs:result})
      })
      .catch((err)=>{
        console.log(err);
      });
  });


app.get('/blogs/create', (req, res) => {
    res.render('create', { title: 'Create a new blog' });
  });

  app.post('/blogs',(req,res)=>{
    const blog = new Blog(req.body);
    blog.save()
      .then((result)=>{
        res.redirect('/blogs');
      })
      .catch((err)=>{
        console.log(err);
      })
  });

 app.get('/blogs/:id',(req,res)=>{
    const id = req.params.id;
    Blog.findById(id)
    .then((result)=>{
      res.render('details',{blog: result, title: 'Blog Details'});
    })
    .catch((err)=>{
      console.log(err);
    });
  });

;


const url = "mongodb+srv://sukuna:test1234@cluster0.2jzxk.mongodb.net/nodeJS?retryWrites=true&w=majority";
mongoose.connect(url,(err,db)=>{
  if(err){
    console.log(err);
  }
  else{
    console.log("Connected");
    app.listen(3000);
  }
});





